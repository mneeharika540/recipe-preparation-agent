

Recipe Agent is a Python-based application that helps users find recipes based on the ingredients they have. It uses *Streamlit* for a simple frontend interface and stores recipes in a JSON file for easy management.

---



- Enter ingredients and get matching recipes
- Shows ingredients, steps, and calorie count
- Easy to add or modify recipes using a .json file
- Streamlit UI – no need for HTML/CSS
- Optional backend with Flask for real-time API access



Example: User enters "tomato, egg, onion, spices" and gets Tomato Egg Curry.

> You can add a screenshot here by uploading an image and adding:

```markdown
![Recipe Agent Screenshot](screenshot.png)