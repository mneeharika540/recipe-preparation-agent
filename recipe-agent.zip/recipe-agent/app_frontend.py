import streamlit as st

recipes = [
    {
        "name": "Tomato Egg Curry",
        "ingredients": ["tomato", "egg", "onion", "spices"],
        "steps": [
            "Heat oil in a pan",
            "Add onions and sauté",
            "Add tomatoes and spices",
            "Add boiled eggs and cook for 5 minutes"
        ],
        "calories": 250
    },
    {
        "name": "Tomato Sandwich",
        "ingredients": ["bread", "tomato", "salt"],
        "steps": [
            "Slice the tomato",
            "Place on bread",
            "Sprinkle salt",
            "Serve"
        ],
        "calories": 150
    }
]
recipes = [
    {
        "name": "Tomato Egg Curry",
        "ingredients": ["tomato", "egg", "onion", "spices"],
        "steps": [
            "Heat oil in a pan",
            "Add onions and sauté",
            "Add tomatoes and spices",
            "Add boiled eggs and cook for 5 minutes"
        ],
        "calories": 250
    },
    {
        "name": "Tomato Sandwich",
        "ingredients": ["bread", "tomato", "salt"],
        "steps": [
            "Slice the tomato",
            "Place on bread",
            "Sprinkle salt",
            "Serve"
        ],
        "calories": 150
    },
    {
        "name": "Vegetable Fried Rice",
        "ingredients": ["rice", "carrot", "peas", "beans", "soy sauce", "oil"],
        "steps": [
            "Heat oil in a pan",
            "Add vegetables and sauté",
            "Add cooked rice and soy sauce",
            "Mix well and cook for 2-3 minutes"
        ],
        "calories": 350
    },
    {
        "name": "Boiled Egg",
        "ingredients": ["egg", "water"],
        "steps": [
            "Place eggs in water",
            "Boil for 10 minutes",
            "Remove and cool"
        ],
        "calories": 80
    },
    {
        "name": "Curd Rice",
        "ingredients": ["rice", "curd", "salt", "mustard", "green chili", "ginger"],
        "steps": [
            "Cook rice and cool it",
            "Mix with curd and salt",
            "Prepare tempering with mustard, chili, and ginger",
            "Add tempering to rice and mix"
        ],
        "calories": 300
    },
    {
        "name": "Maggi Noodles",
        "ingredients": ["noodles", "water", "spices"],
        "steps": [
            "Boil water",
            "Add noodles and spices",
            "Cook for 2 minutes"
        ],
        "calories": 310
    }
]

st.title("🍽 Recipe Agent")
st.markdown("*Enter ingredients you have. I will suggest recipes that match them!*")

user_input = st.text_input("Enter ingredients (comma-separated):")

if st.button("Find Recipes"):
    if user_input:
        input_ingredients = set(i.strip().lower() for i in user_input.split(","))
        found = []

        for recipe in recipes:
            if set(recipe["ingredients"]).issubset(input_ingredients):
                found.append(recipe)

        if found:
            st.success(f"Found {len(found)} matching recipe(s)!")
            for recipe in found:
                st.subheader(recipe["name"])
                st.markdown("*Ingredients:* " + ", ".join(recipe["ingredients"]))
                st.markdown("*Steps:*")
                for step in recipe["steps"]:
                    st.markdown(f"- {step}")
                st.markdown(f"*Calories:* {recipe['calories']}")
                st.markdown("---")
        else:
            st.warning("No matching recipes found.")
    else:
        st.error("Please enter at least one ingredient.")