
from flask import Flask, request, jsonify
from flask_cors import CORS
import random
app = Flask(__name__)
CORS(app)  
recipes = [
    {
        "name": "Tomato Egg Curry",
        "ingredients": ["tomato", "egg", "onion", "spices"],
        "steps": [
            "Heat oil in a pan",
            "Add chopped onions and sauté",
            "Add tomatoes and spices",
            "Add boiled eggs and simmer for 5 minutes"
        ],
        "calories": 250
    },
    {
        "name": "Paneer Fried Rice",
        "ingredients": ["paneer", "rice", "soy sauce", "vegetables"],
        "steps": [
            "Heat oil in a wok",
            "Add vegetables and stir-fry",
            "Add cooked rice and soy sauce",
            "Add paneer cubes and fry for 2 minutes"
        ],
        "calories": 430
    },
    {
        "name": "Cheese Sandwich",
        "ingredients": ["bread", "cheese", "butter"],
        "steps": [
            "Butter the bread slices",
            "Place cheese between two slices",
            "Grill until golden brown"
        ],
        "calories": 300
    }
]

def find_recipes(user_ingredients):
    matches = []
    for recipe in recipes:
        if any(ingredient.lower() in [item.lower() for item in user_ingredients] for ingredient in recipe['ingredients']):
            matches.append({
                "name": recipe["name"],
                "ingredients": recipe["ingredients"],
                "calories": recipe["calories"]
            })
    return matches

@app.route('/get-recipes', methods=['POST'])
def get_recipes():
    data = request.json
    user_ingredients = data.get("ingredients", [])
    matched = find_recipes(user_ingredients)
    if not matched:
        return jsonify({"message": "No recipes found for the given ingredients."})
    return jsonify({"recipes": matched})

@app.route('/get-steps', methods=['POST'])
def get_steps():
    data = request.json
    recipe_name = data.get("recipe_name")
    for recipe in recipes:
        if recipe['name'].lower() == recipe_name.lower():
            return jsonify({
                "steps": recipe['steps'],
                "calories": recipe['calories']
            })
    return jsonify({"message": "Recipe not found."})

@app.route('/', methods=['GET'])
def welcome():
    return jsonify({"message": "Welcome to the Recipe Preparation Agent API!"})

if __name__ == '__main__':
    app.run(debug=True)
